#include <stdio.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define OUTBUF_SIZE 8192 //Buffer size
typedef unsigned int THREADID;

#ifdef X86_32
typedef unsigned int ADDRINT;
#endif

#ifdef X86_64
typedef unsigned long long ADDRINT;
#endif


typedef struct _buf_info_t {
	char buf[OUTBUF_SIZE];
	size_t sofar;
} buf_info_t;

typedef struct {
	buf_info_t* buffer;													// Buffer for writing to file
	//syscall_tracer* syscallEntry;										// Pointer to syscall entry for printing syscall info after execution
	uint call_number;													// Counter used to differentiate calls during post-processing 
	FILE* OutFile;														// Output File
	void(*file_write)(THREADID, buf_info_t*, FILE*, const char*, ...);	// Pointer to function for opening file/writing to file
	THREADID threadid;													// Threadid
} bluepill_tls;

extern "C"
{
	// typedef ssize_t(*Fp_fprintf)(file_t f, const char *fmt, ...);
	// Fp_fprintf my_fprintf;


	void my_init(void)__attribute__((constructor));
	void my_init()
	{    

	}
#ifdef X86_32
int  f_hookpre_0x400706(bluepill_tls *tdata,ADDRINT *r_EDI,ADDRINT *r_ESI,ADDRINT *r_EDX,ADDRINT *r_ECX,ADDRINT *r_EAX,ADDRINT *r_EBX,ADDRINT *r_EBP,ADDRINT *r_ESP)
{
	(tdata->file_write)(tdata->threadid, tdata->buffer, tdata->OutFile, "[hook]|r_EDI:%p r_ESI:%p r_EBX:%p r_EDX:%p r_ECX:%p r_EAX:%p r_EBP:%p r_ESP:%p \n",*r_EDI,*r_ESI,*r_EBX,*r_EDX,*r_ECX,*r_EAX,*r_EBP,*r_ESP);
	return 0;
}
#endif

#ifdef X86_64
int  f_hookpre_0x400706(bluepill_tls *tdata,ADDRINT *r_RDI,ADDRINT *r_RSI,ADDRINT *r_RDX,ADDRINT *r_RCX,ADDRINT *r_R8,ADDRINT *r_R9,ADDRINT *r_RAX,ADDRINT *r_RBX,ADDRINT *r_RBP,ADDRINT *r_RSP,ADDRINT *r_R10,ADDRINT *r_R11,ADDRINT *r_R12,ADDRINT *r_R13,ADDRINT *r_R14,ADDRINT *r_R15)
{
	*r_RDI = 11;
	*r_RSI = 12;
	*r_RDX = 13;
	*r_RCX = 14;
	*r_R8 = 15;
	*r_R9 = 16;
	*(ADDRINT *)(*r_RSP + (7-6) * 8) = 17;
	*(ADDRINT *)(*r_RSP + (8-6) * 8) = 18;
	(*tdata->file_write)(tdata->threadid, tdata->buffer, tdata->OutFile, "[hook]|test r_RDI:%p\n",*r_RDI);

	return 0;
}
#endif
	int main()
	{
		return 0 ;
	}
}
